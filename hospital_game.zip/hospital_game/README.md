![](https://github.com/sammburr/Basic-FPS-Player-GODOT-4.0/blob/4929a04b2791b13184eea82ead9caaf57894be48/addons/Basic%20FPS%20Player/Assets/Basic%20FPS%20Player.png)

# Basic-FPS-Player-GODOT-4.0
(`GDScript`) Godot 4.0 *very* basic FPS player controller with mouse and keyboard input for a kick start in your fps project.
Current version **V1.2**
- Basic walk + jump
- Head bob
- Mouse acceleration + smoothing
- Easy action rebinding

## Installation
See: [Youtube Installation Video](https://www.youtube.com/watch?v=-yS7S-bYY3s)

## Usage
All relevant settings are exported to godot to tweak within the editor.

The character will only listen to mouse input when the mouse is captured; 
(`Input.mouse_mode = Input.MOUSE_MODE_CAPTURED`).

Enjoy! :)
